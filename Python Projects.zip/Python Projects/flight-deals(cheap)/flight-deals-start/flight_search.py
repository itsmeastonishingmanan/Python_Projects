import requests

TEQUILA_ENDPOINT="https://tequila-api.kiwi.com"
TEQUILIA_API_KEY=""

class FlightSearch:

    def get_destination_code(selfself,city_name):
        code="TESTING"
        return code

    #This class is responsible for talking to the Flight Search API.
