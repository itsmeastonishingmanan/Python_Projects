import os
import requests
from twilio.rest import Client
from twilio.http.http_client import TwilioHttpClient



OWM_Endpoint = "https://api.openweathermap.org/data/2.5/forecast"
api_key = "2471442b59367768ed63ecd46f0432d2"
account_sid = 'ACd7b003e6d95f33f19dd502994c694c4d'
auth_token = 'baeb3a57e0a1ac1062f99896c5054a3d'

parameters = {
    "lat": 26.920980,
    "lon": 75.794220,
    "appid": api_key,
    "cnt": 4,
}
response = requests.get(OWM_Endpoint, params=parameters)
response.raise_for_status()
weather_data = response.json()
print(weather_data)

will_rain = False
for hour_data in weather_data["list"]:
    condition_code = print(hour_data["weather"][0]["id"])
    if int(condition_code) < 700:
        print("Bring an Umbrella.")
        will_rain = True

if will_rain:
    proxy_client=TwilioHttpClient()
    proxy_client.session.proxies=("https":os.environ["https_proxy"]
    client = Client(account_sid, auth_token,http_client=proxy_client)

    message = client.messages.create(
        body="It's going to rain today. Remember to bring an ☔",
        from_='+18013969964',
        to='Your verified number',
    )

    print(message.status)
